package DraftTask1;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
// import class for user input random number and arrays 
public class SortingTask1 {



static Scanner scan = new Scanner(System.in);
public static void main(String[] args) {
	System.out.println("-*-*-*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*\n");
	System.out.println("Sorting Algorithm Java implimnetation in 3 ways. Coded by Rashed Haider\n");
	System.out.println("-*-*-*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*\n");
	System.out.println("THIS PROGRAM SHALL DISPLAY THREE OUTPUT \n 1. DISPALY RANDOMISE UNSORTED ARRAY. \n 2. DISPLAY SORTED ARRAY. \n 3. TIME TAKEN TO EXECUTE SORTING \n");

RashedHaider();
}
/** Welcome message and instruction. 
* Interface that prompts the user to select one of 4 option.
* 
* A random array of numbers is created through arrayGenerator method.
* a switch statement used. and sorting-time in milliseconds,
* are display on the console. */
private static void RashedHaider(){
	while (true){
		System.out.println("PLEASE SELECT A SORTING ALGORITHM FROM BELOW : \n \n[1] BUBBLE SORTING"
							+ " \n[2] INSERTION SORTING"
		+ "\n[3] QUICK SORTING \n[4] EXIT");
		// scanner class will ask user input 
		int sortingAlgorithm = scan.nextInt();
		scan.nextLine(); 
		if(sortingAlgorithm == 4)System.exit(0);
		// if statement to exit the console program
		System.out.println("KEY IN THE LENGTH OF ARRAY TO SORT:");
		int userArrayLength = scan.nextInt();
		scan.nextLine();
		int[] newArray = arrayGenerator(userArrayLength); 
		// Print statement to display unsorted array from the array generator class.
		System.out.println("This is a ramdomly generated unsorted array : \n ");
		System.out.println(Arrays.toString(newArray));
		
	switch(sortingAlgorithm){
		
		// Switch statement to select the sorting algorithm or to exit the program.
		
		case 1: 
		System.out.println("Sorted through Bubble Sort:");
		// Time complexity calculation for bubble sort in milliseconds .
		long startTime = System.currentTimeMillis();
		System.out.println(Arrays.toString(bubbleSorting.sort(newArray)));
		System.out.println(userArrayLength + " "+"Array Elements Bubble sorted in: " +
		((System.currentTimeMillis() - startTime)) +
		" milliseconds \n");
		
		break;
		
		case 2:
		System.out.println("Sorted through Insertion Sorting Algorithm: \n");
		// Time complexity calculation for insertion sort in milliseconds .
		startTime = System.currentTimeMillis();
		System.out.println(Arrays.toString(insertionSorting.sort(newArray)));
		System.out.println(userArrayLength + " "+"Array Elements Insertion sorted in: " +
		((System.currentTimeMillis() - startTime)) +
		" milliseconds \n");
		break;
		
		case 3:
		System.out.println("Sorted through Quick Sorting Algorithm: \n");
		// Time complexity calculation for quick sort in milliseconds .
		startTime = System.currentTimeMillis();
		System.out.println(Arrays.toString(quickSorting.sort(newArray)));
		System.out.println(userArrayLength + " "+"Array Elements Quick sorted in: " +
		((System.currentTimeMillis() - startTime)) +
		" milliseconds \n");
		break;
		
		case 4:
		System.exit(0);
		break;
		}
		}
		}

	private static int[] arrayGenerator(int userArrayLength){
		// This class generate random array to the program in relation to the user array length 
		int[] newArray = new int[userArrayLength];
		Random rand = new Random();
		// Using for loop to loop through length of the array and generate any random number with the value up to 10,000.
		for(int i = 0; i < newArray.length; ++i){
		// Setting the parameter as require here 
		newArray[i] = rand.nextInt(10000);}
		return newArray;
		}
		}

class bubbleSorting{
		// This class represents bubble sorting in action. 
		public static int[] sort(int[] userInputArray){
		// Using nested for loop starting form index 0 up to the input array length 
		for(int i = 0; i < userInputArray.length; i++){
			// 
			boolean isbubbleSortinged = true;
			
				for(int j = 1; j < userInputArray.length -i; j++){
				if(userInputArray[j] < userInputArray[j-1]){
				int tem = userInputArray[j];
				userInputArray[j] = userInputArray[j-1];
				userInputArray[j-1] = tem;
				isbubbleSortinged = false;
				}
		}
		if (isbubbleSortinged) return userInputArray;
		}
		return userInputArray;
		}
		}

class insertionSorting{
	// This class represents insertion sorting in action. 

		public static int[] sort(int[] userInputArray){
			
			for(int i=1; i < userInputArray.length; ++i){
				/* Shift element of i starting from index 1 up length of array
				 * Temporary variable is created to compare the value 
				 * j is created in relation with i 
				 */
				int tempValue = userInputArray[i];
				int j = i-1;
				
				
			while(j >= 0 && userInputArray[j] > tempValue){
				/*Loop through and compare the value 
				 * Decrement j
				 */
			userInputArray[j+1] = userInputArray[j];
			j--;
			}
			userInputArray[j+1] = tempValue;
			}
			
		return userInputArray;
		}
		}

class quickSorting{
	/*Selects the last element as quickSortingPivot element, places that quickSortingPivot element correctly in the array in such a way
 	  that all the elements to the left of the quickSortingPivot are smaller than the quickSortingPivot and
      all the elements to the right of quickSortingPivot are larger than it.
	 *
	 */

	public static int[] sort(int[] userInputArray){
	// method that returns userInputArray to the 
		return sort(userInputArray, 0, userInputArray.length-1);
}

	public static int[] sort(int[] userInputArray, int quickSortingLowIndex, int quickSortingHighIndex){
		if(quickSortingLowIndex >= quickSortingHighIndex){
			return userInputArray;
			}
		
			int leftPointer = quickSortingLowIndex;
			int rightPointer = quickSortingHighIndex;
			int quickSortingPivotPosition = new Random().nextInt(quickSortingHighIndex - quickSortingLowIndex) + quickSortingLowIndex;
			int quickSortingPivot = userInputArray[quickSortingPivotPosition];
			
			swap(userInputArray, quickSortingPivotPosition, quickSortingHighIndex);
			
		while(leftPointer < rightPointer){
			while(userInputArray[leftPointer] <= quickSortingPivot && leftPointer < rightPointer){
				leftPointer++;
			}
			while(userInputArray[rightPointer] >= quickSortingPivot && rightPointer > leftPointer){
				rightPointer--;
			}
		
			//swap element when quickSortingPivot number with maximum than quickSortingPivot number
			swap(userInputArray, leftPointer, rightPointer);
		}
		//The while loop ends, swap if element value where pointers meet > quickSortingPivot
		if(userInputArray[leftPointer] > userInputArray[quickSortingHighIndex]) {
			
		//If current element is smaller than the quickSortingPivot, swap the element with quickSortingPivot
			swap(userInputArray, leftPointer, quickSortingHighIndex);
		}
		
		else {
		leftPointer = quickSortingHighIndex;}
		sort(userInputArray, quickSortingLowIndex, rightPointer -1);
		sort(userInputArray, rightPointer +1, quickSortingHighIndex);
	
		return userInputArray;
}
	private static int[] swap(int[] inputArr, int minNum, int maxNum){
		// This method do swap with min and max.
		int x = inputArr[minNum];
		inputArr[minNum] = inputArr[maxNum];
		inputArr[maxNum] = x;
		return inputArr;
		}
		}